Secure Mode Active!
